//---------------------------------------------------------------------------

#ifndef STLH
#define STLH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include <set>
#include <deque>
#include <stack>
#include <Algorith>
typedef enum {LIST, SET, STACK, QUEUE, DEQUE, VECTOR} CONTAINER;
typedef enum {IS_INT, IS_STRING} TYPE;
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
   TRadioGroup *rgCont;
   TRadioGroup *rgDataType;
   TLabel *Label1;
   TMemo *mData;
   TEdit *eAdd;
   TEdit *eFront;
   TEdit *eBack;
   TEdit *eBegin;
   TEdit *eEnd;
   TEdit *erBegin;
   TEdit *erEnd;
   TEdit *eInsertIT;
   TLabel *Label2;
   TPanel *pFrontBack;
   TButton *bFront;
   TButton *bBack;
   TPanel *pIT;
   TLabel *Label4;
   TButton *bBegin;
   TButton *ebnd;
   TButton *brBegin;
   TButton *brEnd;
   TPanel *pInsert;
   TLabel *Label5;
   TButton *bInsert;
   TPanel *pErase;
   TEdit *eEraseIT1;
   TLabel *Label7;
   TLabel *Label8;
   TEdit *eEraseIT2;
   TButton *eErase;
   TPanel *pFind;
   TButton *bFind;
   TButton *bCount;
   TEdit *eFindIT;
   TEdit *eCount;
   TButton *bClear;
   TPanel *pTop;
   TEdit *eTop;
   TButton *bTop;
   TButton *bSort;
   TPanel *pSize;
   TButton *bSize;
   TEdit *eSize;
   TButton *bEmpty;
   TEdit *eEmpty;
   TButton *bReverse;
   TButton *bReset;
   TPanel *pPushPop;
   TButton *bPush;
   TButton *bPop;
   TPanel *pBoth;
   TButton *bPF;
   TButton *bPopF;
   TButton *bPB;
   TButton *bPopB;
   TButton *bShrink;
   TBitBtn *bMore;
   TButton *bInfo;
   void __fastcall rgContClick(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall rgDataTypeClick(TObject *Sender);
   void __fastcall bPFClick(TObject *Sender);
   void __fastcall bPopFClick(TObject *Sender);
   void __fastcall bFrontClick(TObject *Sender);
   void __fastcall bBackClick(TObject *Sender);
   void __fastcall bPBClick(TObject *Sender);
   void __fastcall bPopBClick(TObject *Sender);
   void __fastcall bSizeClick(TObject *Sender);
   void __fastcall bEmptyClick(TObject *Sender);
   void __fastcall bInsertClick(TObject *Sender);
   void __fastcall eEraseClick(TObject *Sender);
   void __fastcall bBeginClick(TObject *Sender);
   void __fastcall ebndClick(TObject *Sender);
   void __fastcall brBeginClick(TObject *Sender);
   void __fastcall brEndClick(TObject *Sender);
   void __fastcall bFindClick(TObject *Sender);
   void __fastcall bCountClick(TObject *Sender);
   void __fastcall bSortClick(TObject *Sender);
   void __fastcall bTopClick(TObject *Sender);
   void __fastcall bReverseClick(TObject *Sender);
   void __fastcall bClearClick(TObject *Sender);
   void __fastcall bResetClick(TObject *Sender);
   void __fastcall bPushClick(TObject *Sender);
   void __fastcall bPopClick(TObject *Sender);
   void __fastcall bShrinkClick(TObject *Sender);
//   void __fastcall pMoreClick(TObject *Sender);
   void __fastcall bMoreClick(TObject *Sender);
   void __fastcall bInfoClick(TObject *Sender);
private:	// User declarations
   void __fastcall MoveDown(void);
   void __fastcall MoveUp(void);
   void __fastcall CopyMemo(void);
   void __fastcall TForm1::UpdateMemo(void);

public:		// User declarations
   __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
