//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Info.h"
#include "STL.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TInfoForm *InfoForm;
extern CONTAINER Container;
#define Add  mInfo->Lines->Add  // Adds() a line (String) to memo
//---------------------------------------------------------------------------
__fastcall TInfoForm::TInfoForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TInfoForm::FormShow(TObject *Sender)
{  mInfo->Clear();
   Add("The elements of a container can be either a number or a string.");
   Add("All containers can dynamically grow or shrink in size.");
   switch (Container)
   {  case LIST:
         Add("A list is a container with the followinf properties:");
         Add("  Supports iterators but not indexing.");
         Add("  Elements can be added by using push_front() or push_back().");
         Add("  Elements use front() or back() to read or change them.");
         Add("  Elements can be removed by pop_front() or pop_back().");
         Add("  Use size() to read the number of elements (int).");
         Add("  Use empty() to see if it is empty (true/false).");
         Add("  Can use iterators to read, add, or remove elements.");
         Add("  An element can iserted at an iterator using insert().");
         Add("  Elements can be deleted using erase().");
         Add("    If only one iterator it removes the element there.");
         Add("    If two iterators it removes between first and last, including first.");
         Add("  Use clear() to romove all elements.");
         break;
      case SET:
         Add("A set is a container with the followinf properties:");
         Add("  Elements can not be accessed by index.");
         Add("  All elements are constant unique values.");
         Add("  Use size() to read the number of elements (int).");
         Add("  Use empty() to see if it is empty (true/false).");
         Add("  Can use iterators to read, add, or remove elements.");
         Add("  An element can iserted at an iterator using insert().");
         Add("  Elements can be deleted using erase().");
         Add("  Use find() to get the location of an elements.");
         Add("  Use count() to get the number of elements with a certain value.");
         Add("    Since all elements are unique, this should aleays be 1.");
         Add("  Use clear() to romove all elements.");
         break;
      case STACK:
         Add("A stack is a container with the followinf properties:");
         Add("  You push or pop an element from the front.");
         Add("  Does not support indexing or iterators.");
         Add("  Use top() ot read or change the first element.");
         Add("  Use push() or pop() to add/remove an element from front.");
         Add("  Use size() to read the number of elements (int).");
         Add("  Use empty() to see if it is empty (true/false).");
         break;
      case QUEUE:
         Add("A queue is a container with the followinf properties:");
         Add("  You push an element to the front.");
         Add("  You pop an element from the back.");
         Add("  Does not support indexing or iterators.");
         Add("  Does not support indexing or iterators.");
         Add("  Use front() or back() to access the first or last element.");
         Add("  Use size() to read the number of elements (int).");
         Add("  Use empty() to see if it is empty (true/false).");
         break;
      case DEQUE:
         Add("A deque is a container with the followinf properties:");
         Add("   This is a double ended queue where you push to front and pop from");
         Add("    the back. You can also push to back and pop from front.");
         Add("    You can push or pop an element to the front or back if you want.");
         Add("  Supports both indexing or iterators.");
         Add("  You can use iterators to read, add, or remove elements.");
         Add("  An element can be iserted at an iterator using insert().");
         Add("  Elements can be deleted using erase().");
         Add("    If only one iterator it removes the element there.");
         Add("    If two iterators it removes between first and last, including first.");
         Add("  Use front() or back() to access the first or last element.");
         Add("  Use push_front or push_back to add an element to the front or back.");
         Add("  Use pop_front or pop_back to remove an element to the front or back.");
         Add("  Use size() to read the number of elements (int).");
         Add("  Use empty() to see if it is empty (true/false).");
         Add("  Use shrink_to_fit() to reduce memory to fit the number of elements.");
         Add("  Use clear() to remove all elements.");
         break;
      case VECTOR:
         Add("A vector is a container with the followinf properties:");
         Add("  You can only add or remove elements from the back.");
         Add("  Supports both indexing or iterators.");
         Add("  Use front() or back() to access the first or last element.");
         Add("  Use push_back to add an element to the back.");
         Add("  Use pop_back to remove an element from the back.");
         Add("  You can use iterators to read, add, or remove elements.");
         Add("  An element can iserted at an iterator using insert().");
         Add("  Elements can be deleted using erase().");
         Add("    If only one iterator it removes the element there.");
         Add("    If two iterators it removes between first and last, including first.");
         Add("  Use size() to read the number of elements (int).");
         Add("  Use empty() to see if it is empty (true/false).");
         Add("  Use shrink_to_fit() to reduce memory to fit the number of elements.");
         Add("  Use clear() to remove all elements.");
   }
   bOK->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TInfoForm::bOKClick(TObject *Sender)
{  ModalResult = 1;
}
//---------------------------------------------------------------------------
