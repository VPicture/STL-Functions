//---------------------------------------------------------------------------
// This uses a STL deque to see what really happens with deque functions
// If the elements change, it refreshes the memo (UpdateMemo)
#include <vcl.h>
#pragma hdrstop

#include "STL.h"
#include "More.h"
#include "Info.h";
#define Line mData->Lines->Strings
// Line[x] would access the xth String
#define Add  mData->Lines->Add  // Adds() a line (String) to memo
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
using namespace std;
TForm1 *Form1;
CONTAINER Container;    // Container type
TYPE Type;              // Type of deque (int or string)
int c, *p, NumData[] =  {1,3,9,5,7,4,2,6,8,0};
String s, *sp, StrData[]= {"Jon", "Bob", "Joe", "Jim", "Sam", "Sue", "end"};
bool Init = 0;    // Flag to tell in container is populated
// Mahe STL deque and iterator for int and string
deque<int> MyInt;
deque<string> MyStr;
deque<int>::iterator II;
deque<string>::iterator IS;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormShow(TObject *Sender)
{  rgDataTypeClick(this);  // Will call rgCont to fill in mData
   bMore->Caption = "More\nFunctions"; // Make 2 line button
}
//---------------------------------------------------------------------------
void __fastcall TForm1::UpdateMemo(void)
{  int i, size;

   mData->Clear();
   if (Type == IS_INT)
   {  size = MyInt.size();
      for (i=0; i < size; i++)
         Add(IntToStr(MyInt[i]));
   }
   else
   {  size = MyStr.size();
      for (i=0; i < size; i++)
         Add(MyStr[i].c_str());
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::rgContClick(TObject *Sender)
{  String s;

   Container = (CONTAINER)rgCont->ItemIndex;
   if (! Init)
   {  mData->Clear();
      switch (Type)
      {  case IS_INT:   MyInt.clear();
                        p = NumData;
                        while (*p != 0)
                        {  c = *p++;
                           MyInt.push_back(c);
                           Add(IntToStr(c));
                        }
                        break;
         case IS_STRING: MyStr.clear();
                        sp = StrData;;
                        while (*sp != "end")
                        {  s = *sp++;
                           MyStr.push_back(s.c_str());
                           Add(s);
                        }
      }
   }
   Init = 1;
   switch (Container)
   {  case LIST:
            // Panels
                  pTop->Visible = 0;
                  pIT->Visible = 1;
                  pFrontBack->Visible = 1;
                  pInsert->Visible = 1;
                  pErase->Visible = 1;
                  pFind->Visible = 0;
                  pSize->Visible = 1;
                  bPF->Visible = 1;
                  pBoth->Visible = 1;
                  pPushPop->Visible = 0;
            // Buttons
                  bClear->Visible = 1;
                  bShrink->Visible = 0;
                  bReverse->Visible = 1;
                  bSort->Visible = 1;
                  break;
      case SET:
            // Panels
                  pIT->Visible = 1;
                  pInsert->Visible = 1;
                  pErase->Visible = 1;
                  pFind->Visible = 1;
                  pTop->Visible = 0;
                  pFrontBack->Visible = 0;
                  pBoth->Visible = 0;
                  pPushPop->Visible = 0;
            // Buttons
                  bClear->Visible = 1;
                  bShrink->Visible = 0;
                  bReverse->Visible = 0;
                  bSort->Visible = 0;
                  break;
      case STACK:
            // Panels
                  pInsert->Visible = 0;
                  pErase->Visible = 0;
                  pFind->Visible = 0;
                  pIT->Visible = 0;
                  pFrontBack->Visible = 0;
                  pTop->Visible = 1;
                  pBoth->Visible = 0;
                  pPushPop->Visible = 1;
                  pPushPop->Left = pBoth->Left;
            // Buttons
                  bClear->Visible = 0;
                  bShrink->Visible = 0;
                  bReverse->Visible = 0;
                  bSort->Visible = 0;
                  break;
      case QUEUE:
            // Panels
                  pInsert->Visible = 0;
                  pErase->Visible = 0;
                  pFind->Visible = 0;
                  pIT->Visible = 0;
                  pFrontBack->Visible = 1;
                  pTop->Visible = 0;
                  pBoth->Visible = 0;
                  pPushPop->Visible = 1;
                  pPushPop->Left = pBoth->Left;
            // Buttons
                  bClear->Visible = 0;
                  bShrink->Visible = 0;
                  bReverse->Visible = 0;
                  bSort->Visible = 0;
                  break;
      case DEQUE:
            // Panels
                  pInsert->Visible = 1;
                  pErase->Visible = 1;
                  pFind->Visible = 0;
                  pIT->Visible = 1;
                  pFrontBack->Visible = 1;
                  pTop->Visible = 0;
                  pBoth->Visible = 1;
                  pPushPop->Visible = 0;
            // Buttons
                  bPF->Visible = 1;
                  bPopF->Visible = 1;
                  bClear->Visible = 1;
                  bShrink->Visible = 1;
                  bReverse->Visible = 0;
                  bSort->Visible = 0;
                  break;
    case VECTOR:
            // Panels
                  pInsert->Visible = 1;
                  pErase->Visible = 1;
                  pFind->Visible = 0;
                  pIT->Visible = 1;
                  pFrontBack->Visible = 1;
                  pTop->Visible = 0;
                  pInsert->Visible = 1;
                  pErase->Visible = 1;
                  pFind->Visible = 0;
                  pBoth->Visible = 1;
                  pPushPop->Visible = 0;
            // Buttons
                  bPF->Visible = 0;
                  bPopF->Visible = 0;
                  bClear->Visible = 1;
                  bShrink->Visible = 1;
                  bReverse->Visible = 0;
                  bSort->Visible = 0;
                  break;
   }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::rgDataTypeClick(TObject *Sender)
{  mData->Clear();
   Type = (TYPE)rgDataType->ItemIndex;;
   Init = 0;
   rgContClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bPFClick(TObject *Sender)
{  String s = eAdd->Text;
   int i, size;

   mData->Clear();
   if (Type == IS_INT)
      MyInt.push_front(StrToInt(s));
   else
      MyStr.push_front(s.c_str());
   UpdateMemo();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bPopFClick(TObject *Sender)
{  if (Type == IS_INT)
      MyInt.pop_front();
   else
      MyStr.pop_front();
   UpdateMemo();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bFrontClick(TObject *Sender)
{  int x;
   String s;

   if (Type == IS_INT)
   {  x = MyInt.front();
      eFront->Text = IntToStr(x);
   }
   else
   {  s = MyStr.front().c_str();
      eFront->Text = s;
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bBackClick(TObject *Sender)
{  int x;
   String s;

   if (Type == IS_INT)
   {  x = MyInt.back();
      eBack->Text = IntToStr(x);
   }
   else
   {  s = MyStr.back().c_str();
      eBack->Text = s;
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bPBClick(TObject *Sender)
{  String s = eAdd->Text;
   int i, size;

   mData->Clear();
   if (Type == IS_INT)
      MyInt.push_back(StrToInt(s));
   else
      MyStr.push_back(s.c_str());
   UpdateMemo();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bPopBClick(TObject *Sender)
{  if (Type == IS_INT)
      MyInt.pop_back();
   else
      MyStr.pop_back();
   UpdateMemo();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bSizeClick(TObject *Sender)
{  int size;

   if (Type == IS_INT)
      size = MyInt.size();
   else
      size = MyStr.size();
   eSize->Text = IntToStr(size);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bEmptyClick(TObject *Sender)
{  bool b;
   String s;

   if (Type == IS_INT)
      b = MyInt.empty();
   else
      b = MyStr.empty();
   if (b)
      s = "True";
   else
      s = "False";
   eEmpty->Text =s;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bInsertClick(TObject *Sender)
{  String data = eAdd->Text;
   int i, Size, Count;
   int x = StrToInt(eInsertIT->Text);  // Iterator position
   set<int> SetInt;    // Make DTL sets
   set<string> SetStr;
// If a set, first check if that value already exists using set,count
   if (Container == SET)
   {  if (Type == IS_INT)
      {  Size = MyInt.size();
         int d = StrToInt(eAdd->Text);       // Data
         set<int>::iterator it = SetInt.begin();   // iterator pointing at begin
         for (i=0; i < Size; i++)      // Populate set
         {  SetInt.insert(it, MyInt[i]);  // Inset at it
            it++;                         // Inc it
         }
         if (SetInt.count(d) > 0)         // If count of d in set > 0
         {  ShowMessage("Same as existing member");
            return;                          // Quit
         }
      }
      else
      {  Size = MyStr.size();
         set<string>::iterator it = SetStr.begin(); // terator pointing at beginn
         for (i=0; i < Size; i++)      // Populate set
         {  SetStr.insert(it, MyStr[i]);
            it++;
         }
         if (SetStr.count(data.c_str()) > 0) // If count of data in set > 0
         {  ShowMessage("Same as existing member");
            return;                          // Quit
         }
      }
   }
// Now insert the data at iterator
   if (Type == IS_INT)
   {  II = MyInt.begin() + x;
      II = MyInt.insert(II, StrToInt(data));
   }
   else
   {  IS = MyStr.begin() + x;
      IS = MyStr.insert(IS, data.c_str());
   }
   UpdateMemo();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::eEraseClick(TObject *Sender)
{  int x1 = StrToInt(eEraseIT1->Text);
   String s2 = eEraseIT2->Text;


   if (Type == IS_INT)
   {  II = MyInt.begin() + x1;
      if (s2 == "")
         MyInt.erase(II);
      else
      {  int x2 = StrToInt(eEraseIT2->Text);
         deque<int>::iterator II2 = MyInt.begin() + x2;
         MyInt.erase(II, II2);
      }
   }
   else
   {  IS = MyStr.begin() + x1;
      if (s2 == "")
         MyStr.erase(IS);
      else
      {  deque<string>::iterator IS2 = MyStr.begin() + StrToInt(s2);
         MyStr.erase(IS, IS2);
      }
   }
   UpdateMemo();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bBeginClick(TObject *Sender)
{  if (Type == IS_INT)
   {  II = MyInt.begin();
      eBegin->Text = IntToStr(distance(MyInt.begin(), II));
   }
   else
   {  IS = MyStr.begin();
      eBegin->Text = IntToStr(distance(MyStr.begin(), IS));
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ebndClick(TObject *Sender)
{  if (Type == IS_INT)
   {  II = MyInt.end();    // end is one past last data
      eEnd->Text = IntToStr(distance(MyInt.begin(), II));
   }
   else
   {  IS = MyStr.end();
      eEnd->Text = IntToStr(distance(MyStr.begin(), IS));
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::brBeginClick(TObject *Sender)
{  if (Type == IS_INT)
   {  II = MyInt.end();
      erBegin->Text = IntToStr(distance(MyInt.begin(), II));
   }
   else
   {  IS = MyStr.end();
      erBegin->Text = IntToStr(distance(MyStr.begin(), IS));
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::brEndClick(TObject *Sender)
{  if (Type == IS_INT)
   {  II = MyInt.begin();
      erEnd->Text = IntToStr(distance(MyInt.begin(), II));
   }
   else
   {  IS = MyStr.begin();
      erEnd->Text = IntToStr(distance(MyStr.begin(), IS));
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bFindClick(TObject *Sender)
{  String s = eAdd->Text;
   int i, size;

   if (Type == IS_INT)
   {  size = MyInt.size();
      int x = StrToInt(s);
      for (i=0; i < size; i++)
         if (MyInt[i] == x)
            break;
   }
   else
   {  size = MyStr.size();
      for (i=0; i < size; i++)
         if (MyStr[i] == s.c_str())
            break;
   }
   if (i == size)
      eFindIT->Text = "NA";
   else
      eFindIT->Text = IntToStr(i);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bCountClick(TObject *Sender)
{  String s = eAdd->Text;
   int i, size, count = 0;

   if (Type == IS_INT)
   {  size = MyInt.size();
      int x = StrToInt(s);
      for (i=0; i < size; i++)
         if (MyInt[i] == x)
            count++;
   }
   else
   {  size = MyStr.size();
      for (i=0; i < size; i++)
         if (MyStr[i] == s.c_str())
            count++;
   }
   eCount->Text = IntToStr(count);
}
//---------------------------------------------------------------------------
int IntSort(const void *a, const void *b)
{  if ((BYTE*)a == (BYTE*)b)
      return 0;
   if ((BYTE*)a < (BYTE*)b)
      return -1;
   else
      return 1;
}
//---------------------------------------------------------------------------
int StrSort(const void *a, const void *b)
{  return (strcmp((char*)a, (char*)b) );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bSortClick(TObject *Sender)
{
   if (Type == IS_INT)
      sort(MyInt.begin(), MyInt.end());
   else  // String
      sort(MyStr.begin(), MyStr.end());
   UpdateMemo();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bTopClick(TObject *Sender)
{  if (Type == IS_INT)
   {  reverse(MyInt.begin(), MyInt.end());   // Reverse so Line[0] will be top
      stack<int> StackInt(MyInt);            // Construct with MyInt members
      reverse(MyInt.begin(), MyInt.end());   // Reverse back
      int TopInt = StackInt.top();
      eTop->Text = IntToStr(TopInt);
   }
   else
   {  reverse(MyStr.begin(), MyStr.end());
      stack<string> StackStr(MyStr);   // Construct with MyStr members
      reverse(MyStr.begin(), MyStr.end());
      String TopStr = StackStr.top().c_str();
      eTop->Text = TopStr;
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bReverseClick(TObject *Sender)
{  if (Type == IS_INT)
      reverse(MyInt.begin(), MyInt.end());
   else
      reverse(MyStr.begin(), MyStr.end());
   UpdateMemo();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bClearClick(TObject *Sender)
{  if (Type == IS_INT)
      MyInt.clear();
   else
      MyStr.clear();
   mData->Clear();
   Init = 0;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bResetClick(TObject *Sender)
{  Init = 0;
   rgContClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bPushClick(TObject *Sender)
{  bPFClick(this);
}
//---------------------------------------------------------------------------
// Need to make deque act like stack to queue
void __fastcall TForm1::bPopClick(TObject *Sender)
{  if (Container == STACK)
   {  if (Type == IS_INT)
         MyInt.pop_front();
      else
         MyStr.pop_front();
   }
   else if (Container == QUEUE)
   {  if (Type == IS_INT)
         MyInt.pop_back();
      else
         MyStr.pop_back();
   }
   UpdateMemo();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bShrinkClick(TObject *Sender)
{  // CBuilder 5 doesn't recognize deque member function shrink_to_fit
/*
   if (Type == IS_INT)
      MyInt.shrink_to_fit();
   else
      MyStr.shrink_to_fit();
*/
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bMoreClick(TObject *Sender)
{  fMore->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bInfoClick(TObject *Sender)
{  InfoForm->ShowModal();
}
//---------------------------------------------------------------------------

