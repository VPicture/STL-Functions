//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "More.h"
#include "stl.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfMore *fMore;
extern CONTAINER Container;
//---------------------------------------------------------------------------
__fastcall TfMore::TfMore(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfMore::FormShow(TObject *Sender)
{  switch (Container)
   {  case LIST: fMore->Caption = "List";
               Label1->Caption = "max_size-Returns maximum size of list";
               Label2->Caption = "assign-Assigns new content to list";
               Label3->Caption = "emplace-Insert element at iterator like insert";
               Label4->Caption = "emplace_front-Insert element at beginning";
               Label5->Caption = "emplace_back-Insert element at end";
               Label6->Caption = "swap-Swaps content with another list";
               Label7->Caption = "resize-Changes size of list";
               Label8->Caption = "splice-Transfer elements fron list to list";
               Label9->Caption = "unique-Remove duplicate members";
               Label10->Caption = "merge-Merge sorted lists";
               Label11->Caption = "= copies one list to another list";
               break;
      case SET:  fMore->Caption ="Set";
               Label1->Caption = "max_size-Returns maximum size of set";
               Label2->Caption = "swap-Swaps content with another set";
               Label3->Caption = "emplace-Insert element at iterator like insert";
               Label4->Caption = "= copies one set to another set";
               Label5->Caption = "";
               Label6->Caption = "";
               Label7->Caption = "";
               Label8->Caption = "";
               Label9->Caption = "";
               Label10->Caption = "";
               Label11->Caption = "";
               break;
      case STACK: fMore->Caption = "Stack";
               Label1->Caption = "emplace-Insert element at iterator like insert";
               Label2->Caption = "";
               Label3->Caption = "";
               Label4->Caption = "";
               Label5->Caption = "";
               Label6->Caption = "";
               Label7->Caption = "";
               Label8->Caption = "";
               Label9->Caption = "";
               Label10->Caption = "";
               Label11->Caption = "";
               break;
      case QUEUE: fMore->Caption = "Queue";
               Label1->Caption = "emplace-Insert element at iterator like insert";
               Label2->Caption = "swap-Swaps content with another queue";
               Label3->Caption = "";
               Label4->Caption = "";
               Label5->Caption = "";
               Label6->Caption = "";
               Label7->Caption = "";
               Label8->Caption = "";
               Label9->Caption = "";
               Label10->Caption = "";
               Label11->Caption = "";
               break;
      case DEQUE: fMore->Caption = "Deque";
               Label1->Caption = "Operator []-Access elements by index";
               Label2->Caption = "max_size-Returns maximum size of deque";
               Label3->Caption = "assign-Assigns new content to deque";
               Label4->Caption = "emplace-Insert element at iterator like insert";
               Label5->Caption = "emplace_back-Insert element at end";
               Label6->Caption = "swap-Swaps content with another deque";
               Label7->Caption = "resize-Changes size of deque";
               Label8->Caption = "";
               Label9->Caption = "";
               Label10->Caption = "";
               Label11->Caption = "";
               break;
      case VECTOR: fMore->Caption = "Vector";
               Label1->Caption = "Operator []-Access elements by index";
               Label2->Caption = "max_size-Returns maximum size of deque";
               Label3->Caption = "assign-Assigns new content to deque";
               Label4->Caption = "emplace-Insert element at iterator like insert";
               Label5->Caption = "emplace_back-Insert element at end";
               Label6->Caption = "swap-Swaps content with another deque";
               Label7->Caption = "resize-Changes size of deque";
               Label8->Caption = "reserve-Request a change in size";
               Label9->Caption = "";
               Label10->Caption = "";
               Label11->Caption = "";
               break;
   }
}
//---------------------------------------------------------------------------

void __fastcall TfMore::bOKClick(TObject *Sender)
{  ModalResult = 1;
}
//---------------------------------------------------------------------------


