//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("StlProj.res");
USEFORM("STL.cpp", Form1);
USEFORM("More.cpp", fMore);
USEFORM("Info.cpp", InfoForm);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
   try
   {
       Application->Initialize();
       Application->CreateForm(__classid(TForm1), &Form1);
       Application->CreateForm(__classid(TfMore), &fMore);
       Application->CreateForm(__classid(TInfoForm), &InfoForm);
       Application->Run();
   }
   catch (Exception &exception)
   {
       Application->ShowException(&exception);
   }
   return 0;
}
//---------------------------------------------------------------------------
